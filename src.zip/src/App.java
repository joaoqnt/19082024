public class App {
    public static void main(String[] args) throws Exception {
        Agencia caixaLuizote = new Agencia("0205-08");
        Conta contaCorrente = new ContaCorrente(caixaLuizote, "1164-9",500d,1000);
        Conta contaPoupanca = new ContaPoupanca(caixaLuizote, "1324-9",3d);
        Conta contaSalario = new ContaSalario(caixaLuizote, "1234-9", 1000d);
        caixaLuizote.addConta(contaPoupanca);
        caixaLuizote.addConta(contaCorrente);
        caixaLuizote.addConta(contaSalario);
        caixaLuizote.saque("1164-9",100);
        caixaLuizote.saque("1324-9", 1);
        caixaLuizote.saque("1234-9", 1000);

    }
}
