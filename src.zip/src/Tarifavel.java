public interface Tarifavel {
    public void tarifar() throws ContaException;

}
