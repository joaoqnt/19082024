public class ContaException extends Exception {

    public ContaException(String msg) {
        super(msg);
    }

}
